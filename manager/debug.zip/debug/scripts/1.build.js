webpackJsonp([1,9],{

/***/ 84:
/***/ function(module, exports, __webpack_require__) {

	var __vue_exports__, __vue_options__
	var __vue_styles__ = {}

	/* styles */
	__webpack_require__(85)

	/* script */
	__vue_exports__ = __webpack_require__(90)

	/* template */
	var __vue_template__ = __webpack_require__(91)
	__vue_options__ = __vue_exports__ = __vue_exports__ || {}
	if (
	  typeof __vue_exports__.default === "object" ||
	  typeof __vue_exports__.default === "function"
	) {
	if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
	__vue_options__ = __vue_exports__ = __vue_exports__.default
	}
	if (typeof __vue_options__ === "function") {
	  __vue_options__ = __vue_options__.options
	}
	__vue_options__.__file = "/Users/ssj/Code/Works/developing/cig/server/manager/src/js/components/pages/login.vue"
	__vue_options__.render = __vue_template__.render
	__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
	__vue_options__._scopeId = "data-v-ad747b50"

	/* hot reload */
	if (false) {(function () {
	  var hotAPI = require("vue-loader/node_modules/vue-hot-reload-api")
	  hotAPI.install(require("vue"), false)
	  if (!hotAPI.compatible) return
	  module.hot.accept()
	  if (!module.hot.data) {
	    hotAPI.createRecord("data-v-ad747b50", __vue_options__)
	  } else {
	    hotAPI.reload("data-v-ad747b50", __vue_options__)
	  }
	})()}
	if (__vue_options__.functional) {console.error("[vue-loader] login.vue: functional components are not supported and should be defined in plain js files using render functions.")}

	module.exports = __vue_exports__


/***/ },

/***/ 85:
/***/ function(module, exports, __webpack_require__) {

	// style-loader: Adds some css to the DOM by adding a <style> tag

	// load the styles
	var content = __webpack_require__(86);
	if(typeof content === 'string') content = [[module.id, content, '']];
	// add the styles to the DOM
	var update = __webpack_require__(89)(content, {});
	if(content.locals) module.exports = content.locals;
	// Hot Module Replacement
	if(false) {
		// When the styles change, update the <style> tags
		if(!content.locals) {
			module.hot.accept("!!./../../../../node_modules/css-loader/index.js!./../../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-ad747b50&scoped=true!./../../../../node_modules/sass-loader/index.js!./../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./login.vue", function() {
				var newContent = require("!!./../../../../node_modules/css-loader/index.js!./../../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-ad747b50&scoped=true!./../../../../node_modules/sass-loader/index.js!./../../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./login.vue");
				if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
				update(newContent);
			});
		}
		// When the module is disposed, remove the <style> tags
		module.hot.dispose(function() { update(); });
	}

/***/ },

/***/ 86:
/***/ function(module, exports, __webpack_require__) {

	exports = module.exports = __webpack_require__(87)();
	// imports


	// module
	exports.push([module.id, "\n.bg[data-v-ad747b50] {\n  background: url(" + __webpack_require__(88) + ") no-repeat center center;\n  background-size: 1920px 1080px;\n  height: 100%;\n}\n.box-card[data-v-ad747b50] {\n  width: 300px;\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  transform: translate3d(-50%, -50%, 0);\n}\nfieldset[data-v-ad747b50] {\n  padding: 5px 20px;\n  margin: 0 2px;\n}\nlegend[data-v-ad747b50] {\n  display: block;\n  width: 40%;\n  margin-bottom: 20px;\n  font-size: 15px;\n  line-height: inherit;\n  color: #333;\n  border: 1px;\n  border-bottom: 0;\n  margin-left: 20px;\n}\n.label-header[data-v-ad747b50] {\n  padding: 5px;\n}\nfieldset.question[data-v-ad747b50] {\n  border: 1px solid #d5d5d5;\n}\n.container-table[data-v-ad747b50] {\n  min-height: 873px;\n}\n.container-table[data-v-ad747b50] {\n  display: table;\n}\n.vertical-center-row[data-v-ad747b50] {\n  display: table-cell;\n  vertical-align: middle;\n}\n.labletitle[data-v-ad747b50] {\n  text-align: left;\n}\n.mg1[data-v-ad747b50] {\n  margin: 10px 0px;\n}\n", ""]);

	// exports


/***/ },

/***/ 88:
/***/ function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__.p + "images/ae805e72e08a5dba715287732b92029d.jpg";

/***/ },

/***/ 89:
/***/ function(module, exports, __webpack_require__) {

	/*
		MIT License http://www.opensource.org/licenses/mit-license.php
		Author Tobias Koppers @sokra
	*/
	var stylesInDom = {},
		memoize = function(fn) {
			var memo;
			return function () {
				if (typeof memo === "undefined") memo = fn.apply(this, arguments);
				return memo;
			};
		},
		isOldIE = memoize(function() {
			return /msie [6-9]\b/.test(window.navigator.userAgent.toLowerCase());
		}),
		getHeadElement = memoize(function () {
			return document.head || document.getElementsByTagName("head")[0];
		}),
		singletonElement = null,
		singletonCounter = 0,
		styleElementsInsertedAtTop = [];

	module.exports = function(list, options) {
		if(true) {
			if(typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
		}

		options = options || {};
		// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
		// tags it will allow on a page
		if (typeof options.singleton === "undefined") options.singleton = isOldIE();

		// By default, add <style> tags to the bottom of <head>.
		if (typeof options.insertAt === "undefined") options.insertAt = "bottom";

		var styles = listToStyles(list);
		addStylesToDom(styles, options);

		return function update(newList) {
			var mayRemove = [];
			for(var i = 0; i < styles.length; i++) {
				var item = styles[i];
				var domStyle = stylesInDom[item.id];
				domStyle.refs--;
				mayRemove.push(domStyle);
			}
			if(newList) {
				var newStyles = listToStyles(newList);
				addStylesToDom(newStyles, options);
			}
			for(var i = 0; i < mayRemove.length; i++) {
				var domStyle = mayRemove[i];
				if(domStyle.refs === 0) {
					for(var j = 0; j < domStyle.parts.length; j++)
						domStyle.parts[j]();
					delete stylesInDom[domStyle.id];
				}
			}
		};
	}

	function addStylesToDom(styles, options) {
		for(var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];
			if(domStyle) {
				domStyle.refs++;
				for(var j = 0; j < domStyle.parts.length; j++) {
					domStyle.parts[j](item.parts[j]);
				}
				for(; j < item.parts.length; j++) {
					domStyle.parts.push(addStyle(item.parts[j], options));
				}
			} else {
				var parts = [];
				for(var j = 0; j < item.parts.length; j++) {
					parts.push(addStyle(item.parts[j], options));
				}
				stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
			}
		}
	}

	function listToStyles(list) {
		var styles = [];
		var newStyles = {};
		for(var i = 0; i < list.length; i++) {
			var item = list[i];
			var id = item[0];
			var css = item[1];
			var media = item[2];
			var sourceMap = item[3];
			var part = {css: css, media: media, sourceMap: sourceMap};
			if(!newStyles[id])
				styles.push(newStyles[id] = {id: id, parts: [part]});
			else
				newStyles[id].parts.push(part);
		}
		return styles;
	}

	function insertStyleElement(options, styleElement) {
		var head = getHeadElement();
		var lastStyleElementInsertedAtTop = styleElementsInsertedAtTop[styleElementsInsertedAtTop.length - 1];
		if (options.insertAt === "top") {
			if(!lastStyleElementInsertedAtTop) {
				head.insertBefore(styleElement, head.firstChild);
			} else if(lastStyleElementInsertedAtTop.nextSibling) {
				head.insertBefore(styleElement, lastStyleElementInsertedAtTop.nextSibling);
			} else {
				head.appendChild(styleElement);
			}
			styleElementsInsertedAtTop.push(styleElement);
		} else if (options.insertAt === "bottom") {
			head.appendChild(styleElement);
		} else {
			throw new Error("Invalid value for parameter 'insertAt'. Must be 'top' or 'bottom'.");
		}
	}

	function removeStyleElement(styleElement) {
		styleElement.parentNode.removeChild(styleElement);
		var idx = styleElementsInsertedAtTop.indexOf(styleElement);
		if(idx >= 0) {
			styleElementsInsertedAtTop.splice(idx, 1);
		}
	}

	function createStyleElement(options) {
		var styleElement = document.createElement("style");
		styleElement.type = "text/css";
		insertStyleElement(options, styleElement);
		return styleElement;
	}

	function addStyle(obj, options) {
		var styleElement, update, remove;

		if (options.singleton) {
			var styleIndex = singletonCounter++;
			styleElement = singletonElement || (singletonElement = createStyleElement(options));
			update = applyToSingletonTag.bind(null, styleElement, styleIndex, false);
			remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true);
		} else {
			styleElement = createStyleElement(options);
			update = applyToTag.bind(null, styleElement);
			remove = function() {
				removeStyleElement(styleElement);
			};
		}

		update(obj);

		return function updateStyle(newObj) {
			if(newObj) {
				if(newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap)
					return;
				update(obj = newObj);
			} else {
				remove();
			}
		};
	}

	var replaceText = (function () {
		var textStore = [];

		return function (index, replacement) {
			textStore[index] = replacement;
			return textStore.filter(Boolean).join('\n');
		};
	})();

	function applyToSingletonTag(styleElement, index, remove, obj) {
		var css = remove ? "" : obj.css;

		if (styleElement.styleSheet) {
			styleElement.styleSheet.cssText = replaceText(index, css);
		} else {
			var cssNode = document.createTextNode(css);
			var childNodes = styleElement.childNodes;
			if (childNodes[index]) styleElement.removeChild(childNodes[index]);
			if (childNodes.length) {
				styleElement.insertBefore(cssNode, childNodes[index]);
			} else {
				styleElement.appendChild(cssNode);
			}
		}
	}

	function applyToTag(styleElement, obj) {
		var css = obj.css;
		var media = obj.media;
		var sourceMap = obj.sourceMap;

		if (media) {
			styleElement.setAttribute("media", media);
		}

		if (sourceMap) {
			// https://developer.chrome.com/devtools/docs/javascript-debugging
			// this makes source maps inside style tags work properly in Chrome
			css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */';
			// http://stackoverflow.com/a/26603875
			css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
		}

		if (styleElement.styleSheet) {
			styleElement.styleSheet.cssText = css;
		} else {
			while(styleElement.firstChild) {
				styleElement.removeChild(styleElement.firstChild);
			}
			styleElement.appendChild(document.createTextNode(css));
		}
	}


/***/ },

/***/ 90:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//
	//

	exports.default = {
	    data: function data() {
	        return {
	            username: "",
	            password: "",
	            loginview: true,
	            newpassword: "",
	            passwordconfirm: ""
	        };
	    },

	    methods: {
	        login: function login() {
	            var _this = this;

	            this.$store.dispatch("login", {
	                username: this.username,
	                password: this.password
	            }).then(function (isFirstLogin) {
	                if (isFirstLogin) {
	                    _this.passwordconfirm = "";
	                    _this.newpassword = "";
	                    _this.loginview = false;
	                } else {
	                    _this.$router.push("/manager");
	                }
	            }, function (err) {
	                _this.$message.error(err);
	            });
	        },
	        modifypassword: function modifypassword() {
	            var _this2 = this;

	            if (this.passwordconfirm != this.newpassword) {
	                this.$message.error("两次密码不一致");
	            } else {
	                this.$store.dispatch("resetPassword", {
	                    password: this.newpassword
	                }).then(function () {
	                    _this2.$router.push("/manager");
	                }, function (err) {
	                    _this2.$message.error(err);
	                });
	            }
	        }
	    }
	};

/***/ },

/***/ 91:
/***/ function(module, exports, __webpack_require__) {

	module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;
	  return _h('div', {
	    staticClass: "bg"
	  }, [(_vm.loginview) ? _h('el-card', {
	    staticClass: "box-card"
	  }, [_h('div', {
	    staticClass: "clearfix",
	    slot: "header"
	  }, [_h('span', {
	    staticStyle: {
	      "line-height": "36px"
	    }
	  }, ["CIG仪器管理系统"])]), " ", _h('div', {
	    staticClass: "text item"
	  }, [_h('el-form', {
	    ref: "form",
	    attrs: {
	      "label-width": "80px"
	    }
	  }, [_h('el-form-item', {
	    attrs: {
	      "label": "用户名"
	    }
	  }, [_h('el-input', {
	    directives: [{
	      name: "model",
	      rawName: "v-model",
	      value: (_vm.username),
	      expression: "username"
	    }],
	    attrs: {
	      "required": ""
	    },
	    domProps: {
	      "value": (_vm.username)
	    },
	    on: {
	      "input": function($event) {
	        _vm.username = $event
	      }
	    }
	  })]), " ", _h('el-form-item', {
	    attrs: {
	      "label": "密码"
	    }
	  }, [_h('el-input', {
	    directives: [{
	      name: "model",
	      rawName: "v-model",
	      value: (_vm.password),
	      expression: "password"
	    }],
	    attrs: {
	      "type": "password"
	    },
	    domProps: {
	      "value": (_vm.password)
	    },
	    on: {
	      "input": function($event) {
	        _vm.password = $event
	      }
	    }
	  })]), " ", _h('el-form-item', [_h('el-button', {
	    attrs: {
	      "type": "primary"
	    },
	    on: {
	      "click": _vm.login
	    }
	  }, ["登陆"])])])])]) : _vm._e(), " ", (!_vm.loginview) ? _h('el-card', {
	    staticClass: "box-card"
	  }, [_h('div', {
	    staticClass: "clearfix",
	    slot: "header"
	  }, [_h('span', {
	    staticStyle: {
	      "line-height": "36px"
	    }
	  }, ["密码重置（首次登陆）"])]), " ", _h('div', {
	    staticClass: "text item"
	  }, [_h('el-form', {
	    ref: "form",
	    attrs: {
	      "label-width": "80px"
	    }
	  }, [_h('el-form-item', {
	    attrs: {
	      "label": "密码"
	    }
	  }, [_h('el-input', {
	    directives: [{
	      name: "model",
	      rawName: "v-model",
	      value: (_vm.newpassword),
	      expression: "newpassword"
	    }],
	    attrs: {
	      "required": "",
	      "type": "password"
	    },
	    domProps: {
	      "value": (_vm.newpassword)
	    },
	    on: {
	      "input": function($event) {
	        _vm.newpassword = $event
	      }
	    }
	  })]), " ", _h('el-form-item', {
	    attrs: {
	      "label": "确认密码"
	    }
	  }, [_h('el-input', {
	    directives: [{
	      name: "model",
	      rawName: "v-model",
	      value: (_vm.passwordconfirm),
	      expression: "passwordconfirm"
	    }],
	    attrs: {
	      "type": "password"
	    },
	    domProps: {
	      "value": (_vm.passwordconfirm)
	    },
	    on: {
	      "input": function($event) {
	        _vm.passwordconfirm = $event
	      }
	    }
	  })]), " ", _h('el-form-item', [_h('el-button', {
	    attrs: {
	      "type": "primary"
	    },
	    on: {
	      "click": _vm.modifypassword
	    }
	  }, ["修改"])])])])]) : _vm._e()])
	},staticRenderFns: []}
	module.exports.render._withStripped = true
	if (false) {
	  module.hot.accept()
	  if (module.hot.data) {
	     require("vue-loader/node_modules/vue-hot-reload-api").rerender("data-v-ad747b50", module.exports)
	  }
	}

/***/ }

});